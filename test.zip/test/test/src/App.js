import './App.css';
import Tutoriales from './components/Tutoriales';

const App = () => {
  return (
    <div className="main" >

      <h1>Lista de Tutoriales</h1>
      <Tutoriales/>
    </div>
  );
}

export default App;
