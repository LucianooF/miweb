import React,{useState} from "react"
const Tutorial = ( {indice, tutorial, url, marcar, borrar} ) =>{


    const [tutorialInputType, setTutorialInputType] = useState('')

    const handleChangeType = e => {
        setTutorialInputType(e.currentTarget.value)
    }



    if(tutorial.activo){
    return(
        <div className='todo' >
            
                <select value={tutorialInputType} onChange={handleChangeType}>
                    <option value="Programacion">Programacion</option>
                    <option value="Matematica">Matematica</option>
                    <option value="Clase Grabada">Clase Grabada</option>

                </select>
            
            {tutorial.nombre}
            <div>
                <button onClick={() => marcar(indice)}>Desactivar Link</button>
                <button onClick={() => borrar(indice)}>Borrar Tutorial</button>
                <a href={url}>Link Tutorial</a>
            </div>
        </div>
    )}
    else{
        return(
            <div className='todo'>
                <select value={tutorialInputType} onChange={handleChangeType}>
                    <option value="Programacion">Programacion</option>
                    <option value="Matematica">Matematica</option>
                    <option value="Clase Grabada">Clase Grabada</option>

                </select>

                {tutorial.nombre}
                <div>
                    <button onClick={() => marcar(indice)}>Activar Link</button>
                    <button onClick={() => borrar(indice)}>Borrar Tutorial</button>
                </div>
            </div>
        )
    }
}

export default Tutorial