import React,{useState} from 'react'


const FormAltaTutorial = ({funcionAgregarTutorial}) => {

    const [tutorialInputName, setTutorialInputName] = useState('')
    const [tutorialInputUrl, setTutorialInputUrl] = useState('')
    const [tutorialInputType, setTutorialInputType] = useState('')


    const handleChangeName = e => {
        setTutorialInputName(e.currentTarget.value)
    }
    const handleChangeUrl = e =>{
        setTutorialInputUrl(e.currentTarget.value)
    }
    const handleChangeType = e => {
        setTutorialInputType(e.currentTarget.value)
    }

    const handleSubmit = (e) => {
        e.preventDefault();
        if(tutorialInputName.length <= 30){
            funcionAgregarTutorial(tutorialInputName, tutorialInputUrl, tutorialInputType);
            setTutorialInputName("");
            setTutorialInputUrl("");
        }
    }

    

    return(
        <div>
            <form onSubmit={handleSubmit}>
                <input value={ tutorialInputName } type="text" onChange={handleChangeName} placeholder="Ingrese un tutorial" />
                
                <input value={ tutorialInputUrl } type="text" onChange={handleChangeUrl} placeholder="URL Tutorial" />
                
                <br />
                <select value={tutorialInputType} onChange={handleChangeType}>
                    <option value="Programacion">Programacion</option>
                    <option value="Matematica">Matematica</option>
                    <option value="Clase Grabada">Clase Grabada</option>

                </select>
                <button>Cargar Tutorial</button>
            </form>
        </div>
    )
}


export default FormAltaTutorial