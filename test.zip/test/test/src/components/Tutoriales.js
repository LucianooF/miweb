import Tutorial from './Tutorial'
import React,{ useEffect, useState} from 'react'
import FormAltaTutorial from './FormAltaTutorial'

const Tutoriales = () =>{
    
    const [tutoriales, setTutoriales] = useState([])
    const [algoHaCambiado, setAlgoHaCambiado] = useState([true])

    useEffect( () => {
        fetch('http://localhost:5000/tutoriales', { method: 'GET' })
        .then( res => res.json() )
        .then( datos => setTutoriales(datos) )
    } , [algoHaCambiado] )

    function existeTutorial(nombre) {
        const t = tutoriales.find( t => t.nombre.toLowerCase() === nombre.toLowerCase() )
        return !(t===undefined)
    }


    const agregarTutorial = (tutorial,url,tipo) => {
        const opciones ={
            method: 'POST',
            headers : {'Content-Type': 'application/json'},
            body : JSON.stringify({nombre: tutorial, url: url, tipo: tipo})
        }
        if(!existeTutorial(tutorial)){
            fetch('http://localhost:5000/tutoriales', opciones)
            .then( res => res.json() )
            .then( datos => setAlgoHaCambiado(!algoHaCambiado) )
            console.log(tutorial)
        } else {
            alert('EL TUTORIAL YA EXISTE')
        }
    }

    const marcarTutorial = index => {
        fetch(`http://localhost:5000/tutoriales/${index}/activo`, {method:'PUT'})
        .then( res => res.json() )
        .then( datos => setAlgoHaCambiado(!algoHaCambiado) )
    };

    const borrarTutorial = index => {
        fetch(`http://localhost:5000/tutoriales/${index}`, {method:'DELETE'})
        .then( res => res.json() )
        .then( datos => {
            setAlgoHaCambiado(!algoHaCambiado)} )
    };

    return(
        <div className="todo-list" >
            <ul>
                {tutoriales.map(
                    (el, idx) => { return (<Tutorial key={idx} indice={el.id} tutorial={el} url={el.url} marcar={marcarTutorial} borrar={borrarTutorial} /> )}
                )}
            </ul>
            <br />
            <FormAltaTutorial funcionAgregarTutorial={agregarTutorial} />
        </div>
    )
}

export default Tutoriales