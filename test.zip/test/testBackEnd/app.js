const express = require('express')
const  cors = require('cors');
const { addListener } = require('nodemon');
const app = express()
const port = 5000

const todos = [
    {"id": 1, "nombre": "algebra", "tipo": "Matematica", "url": "asd","activo": false},
    {"id": 2, "nombre": "laboratorio", "tipo": "Programacion", "url": "asd2","activo": false}

]

app.use(express.json())
app.use(cors());

app.get('/tutoriales' , (req, res) => {
    res.status(200).json( todos )
} )

app.get('/tutoriales/:idTutorial', (req, res) => {
    const idTutorial = req.params.idTutorial
    const tutorial = todos.find( t => t.id == idTutorial)

    if (undefined != tutorial)
        res.status(200).json(tutorial)
    else 
        res.status(404).json( {"Mensaje": `El tutorial ${idTutorial} no fue encontrado` } )
})

app.post('/tutoriales' , (req, res) => {
    const cuerpo = req.body
    const ids = todos.map (t => t.id)
    if(cuerpo.tipo === "Programacion" || cuerpo.tipo === "Matematica" || cuerpo.tipo === "Clase Grabada"){
       const max = ids.length > 0 ? Math.max( ...ids) +1 : 1
       todos.push( { "id": max, "nombre tutorial": cuerpo.nombre[30], "tipo": cuerpo.tipo , "url": cuerpo.url, "activo":false })
       res.status(201).json(todos[todos.length - 1])}
    else{
        res.status(202).json({"Mensaje": `El tipo de tutorial no es soportado, solo: Programacion, Matematica, Clase Grabada`})
    }
    
})

app.delete('/tutoriales/:idTutorial', (req, res) => {
    const idTutorial = req.params.idTutorial
    const tutorial = todos.find( t => t.id == idTutorial)
    if(undefined != tutorial) {
        const idx = todos.indexOf(tutorial)
        todos.splice(idx, 1)
        res.status(202).json( { "Mensaje": `El tutorial ${idTutorial} fue eliminado`, "tutorial": tutorial})
    }
    else 
        res.status(404).json( { "Mensaje": `El tutorial ${idTutorial} no fue encontrado`} )
})

app.put('/tutoriales/:idTutorial/activo', (req, res) => {
    const idTutorial = req.params.idTutorial
    const tutorial = todos.find( t => t.id == idTutorial)
    if (undefined != tutorial) {
        const idx = todos.indexOf(tutorial)
        tutorial.activo = !tutorial.activo
        todos.splice(idx, 1, tutorial)
        res.status(202).json( { "Mensaje": `El tutorial ${idTutorial} fue modificado`, "tutorial": tutorial})
    }
    else 
        res.status(404).json( { "Mensaje": `El tutorial ${idTutorial} no fue encontrado`} )
})

app.listen(port , () => {
    console.log(`Aplicacion iniciada en el puerto local ${port}`)
})